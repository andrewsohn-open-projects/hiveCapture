HiveCapture Screen Capture Batch Tool
=========
Chrome Browser Extension of Screen Capture CSV Batch Tool presented by Hivelab Corp. Samsung Opt Team.


Requires
------------------
 * `jQuery 1.12.0`
 * `Swiper 3.3.1`


Change Log
=====
 * `v 1.3.3`
	 * [new feature] prefix filename insertion
	 * [improved] image filename ordered and specified as its URL
	 
 * `v 1.3.2`
	 * [bug fix] processing popup window remaining open even if capturing is done.
	 
 * `v 1.3.1`
	 * [bug fix] extracting process layer is replaced to new window in order to continue its extraction.
	 
* `v 1.2.1`
	* icon, UI redesign
